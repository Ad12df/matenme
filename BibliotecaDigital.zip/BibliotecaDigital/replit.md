# BiblioDigital - Biblioteca Digital Personal

## Overview
BiblioDigital is a personal digital library web application designed for managing, reading, and organizing digital books. It operates entirely client-side using local storage mechanisms (localStorage and IndexedDB), eliminating the need for a backend or external database for core functionalities. The project aims to provide a privacy-focused, easy-to-use solution with features like book cataloging, personalized reading settings, and a responsive design, free from external service dependencies. The business vision is to offer a fully client-side, self-contained digital library.

## User Preferences
No explicit user preferences were provided in the original `replit.md` file.

## System Architecture

### UI/UX Decisions
-   **Responsive Design**: The application features a fully responsive design for mobile, tablets, and desktop, including a collapsible sidebar and optimized layouts.
-   **Theming**: Nine modern visual themes are available, each with a complete color palette, custom gradients, shadows, and adapted styles for all UI elements, ensuring excellent contrast and legibility.
-   **Authentication Flow**: Designed for optional local authentication, allowing users to explore content as guests. Login is only required for uploading personal books.

### Technical Implementations
-   **Frontend**: Built with HTML5, CSS3 (using variables for styling), and Vanilla JavaScript for application logic.
-   **Book Management**: Includes a catalog with search and filters, book uploads with custom covers, demo books, a favorites feature, and an integrated reader with customizable settings. A "Fiction Express Reader" provides a paginated reading experience for JSON-formatted books.
-   **Local Authentication**: User registration and login are handled via localStorage, with user data stored locally in the browser without an external authentication server.
-   **Customizable Settings**: Allows editing user profiles, configuring visual themes, global font size, reader themes (Light, Dark, Sepia), and notification preferences.

### System Design Choices
-   **Local Storage First**: The core principle is a fully client-side operation using browser storage.
    -   **localStorage**: Used for user data (authentication), book metadata, favorites, custom settings, and base64 encoded book covers.
    -   **IndexedDB**: Used for storing large binary files (PDFs up to 50MB) like `BiblioDigitalDB` with an object store `pdfs` to overcome localStorage limits and optimize binary data storage.
-   **Server**: A simple Python 3 `http.server` is used for serving static files during development on `0.0.0.0:5000` with caching disabled.
-   **Security Considerations (Development)**: Local authentication and storage are for demonstration; production deployment requires robust security measures like password hashing, JWT, HTTPS, and input validation.

## External Dependencies
-   **Python 3.11**: Used for the `http.server` module for local development.
-   **Node.js 20**: Required for npm and Firebase CLI tools.
-   **Firebase SDK v10.7.1**: Integrated for Firestore, Authentication, and Storage. Loaded via CDN with global exposure of services (`window.firebase`, `window.db`, `window.auth`, `window.storage`). The project ID is `bibliotecadigital-ae9a3`.
-   **Firebase CLI v14.20.0**: Used for deployment and management.
-   **PDF.js v3.11.174**: Utilized for PDF rendering and navigation within the advanced reader.
-   **epub.js v0.3.93**: Used for EPUB support in the advanced reader.