#!/bin/bash
# Script para preparar el proyecto para Firebase Hosting

echo "🔨 Preparando proyecto para Firebase deployment..."

# Limpiar carpeta public existente
echo "🧹 Limpiando carpeta public anterior..."
rm -rf public

# Crear carpeta public limpia
mkdir -p public

# Copiar archivos web
echo "📁 Copiando archivos..."
cp -r css js pages config public/
cp index.html favicon.svg favicon.ico public/

echo "✅ Proyecto listo para deployment"
echo "📤 Ejecuta: firebase deploy --only hosting"
